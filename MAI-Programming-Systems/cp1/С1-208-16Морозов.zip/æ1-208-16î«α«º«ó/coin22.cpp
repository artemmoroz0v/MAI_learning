/*  MAB   */
#include "mlisp.h"
double largest/*1*/ (double coins__set);
	 double count__change/*11*/ (double amount);
	 bool Shaeffer_Q/*25*/ (double x_Q, double y_Q);
	 double cc/*29*/ (double amount, double coins__set);
	 double denomination__list/*37*/ (double coins__set);
	 extern double VARIANT/*44*/;
	 extern double COINS/*45*/;
	 //________________ 
double largest/*1*/ (double coins__set){
 return
 ((coins__set == 1.)
	? 3.
	: (coins__set == 2.)
	? 5.
	: (coins__set == 3.)
	? 20.
	: (coins__set == 4.)
	? 25.
	: (0.));
	 }
 
double count__change/*11*/ (double amount){
 display("______");
	 newline();
	 display(" amount: ");
	 display(amount);
	 newline();
	 display("COINS: ");
	 display(COINS);
	 newline();
	 return
 (((0. >= amount) || !((COINS >= 1.)) || (largest(COINS) == 0.))
	? (display("Improper parameter value!\ncount-change= "),
	 -1.)
	: (display("List of coin denominations: "),
	 denomination__list(COINS),
	 display("count-change= "),
	 cc(amount, COINS)));
	 }
 
bool Shaeffer_Q/*25*/ (double x_Q, double y_Q){
 return
 (!(x_Q) || !(y_Q));
	 }

double cc/*29*/ (double amount, double coins__set){
 return
 ((amount == 0.)
	? 1.
	: Shaeffer_Q((amount >= 1.), !((0. >= coins__set)))
	? 0.
	: ((cc(amount, (coins__set - 1.)) + cc((amount - largest(coins__set)), coins__set))));
	 }
 
double denomination__list/*37*/ (double coins__set){
 return
 ((coins__set == 0.)
	? (newline(),
	 0.)
	: (display(largest(coins__set)),
	 display(" "),
	 denomination__list((coins__set - 1.))));
	 }
 
double VARIANT/*44*/ = 16.;
	 
double COINS/*45*/ = 4.;
	 int main(){
 display("Variant ");
	 display(VARIANT);
	 newline();
	 display(count__change(100.));
	 newline();
	 COINS = 13.;
	 display(count__change(100.));
	 newline();
	 display("(c) Artem Morozov 2022");
	 newline();
	 std::cin.get();
	 return 0;
	 }
 
